#include<stdio.h>
#include<stdbool.h>

bool ChkEven(int iNo)
{
	if((iNo%2)==0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int main()
{
	int iValue = 0;
	bool bRet;
	
	printf("Enter number\n");
	scanf("%d",&ivalue);
	
	bRet=ChkEven(iValue);
	if(bRet==true)
	{
		
	}
}