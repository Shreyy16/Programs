#include<stdio.h>

//Demonstration of SEQUENCE

void Display();

int main()
{
	Display();    //Declaration
	
	return 0;     //Function call
}

void Display()     //Defination
{
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
}