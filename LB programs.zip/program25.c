#include<stdio.h>

int ChkEven(int iNO)
{
	if((iNo % 2)==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	int iValue = 0;
	int iRet = 0;
	
	printf("Enter number\2");
	scanf("%d",&iValue);
	
	iRet = ChkEven(iValue);
	if(iRet == 1)
	{
		printf("%d" is even number\n",iValue);
	}
	else
	{
		printf("%d is odd number\n",iValue);
	}
	return 0;
}