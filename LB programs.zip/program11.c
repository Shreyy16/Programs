#include<stdio.h>

void Display()
{
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
	printf("Hello\n");
}
int main()
{
	Display();
	
	return 0;
}