#include<stdio.h>

//Demostration of ITERATION

void Display()   //Defination
{
	int iCnt = 0;
	
	//1 Initialization
	//2 Condition 
	//3 Displacement
	//4 Loop body
	
	for(iCnt=0;iCnt<5;++iCnt)
	{
		printf("Hello\n");
	}
}

int main()
{
	Display();    //Funtion call
	
	return 0;
}