// Program to display 5 times Hello on screen

#include<stdio.h>

// Demonstration of SEQUANCE

int main()
{
	
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    printf("Hello\n");
    
    return 0;
}