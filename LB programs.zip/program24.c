#include<stdio.h>
#include<stdbool.h>

bool Check(int iNo)
{
	if
	{
		((iNo%3)==0)&&
		((
	
}